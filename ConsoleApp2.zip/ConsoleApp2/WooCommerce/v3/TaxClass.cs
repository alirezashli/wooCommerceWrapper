﻿using System.Runtime.Serialization;

namespace WooCommerceNET.WooCommerce.v3
{
    [DataContract]
    public class TaxClass : v2.TaxClass { }
}
