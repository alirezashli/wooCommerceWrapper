﻿using System.Runtime.Serialization;

namespace WooCommerceNET.WooCommerce.v3
{
    [DataContract]
    public class ProductAttribute : v2.ProductAttribute { }

    [DataContract]
    public class ProductAttributeTerm : v2.ProductAttributeTerm { }
}
