﻿using System.Runtime.Serialization;

namespace WooCommerceNET.WooCommerce.v3
{
    [DataContract]
    public class ShippingClass : v2.ShippingClass { }
}
