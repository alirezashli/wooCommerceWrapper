﻿using System;
using System.Runtime.Serialization;

namespace WooCommerceNET.WooCommerce.v3
{
    [DataContract]
    public class OrderNote : v2.OrderNote { }
}
