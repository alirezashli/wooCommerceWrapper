﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace WooCommerceNET.WooCommerce.v3
{
    [DataContract]
    public class SystemStatus : v2.SystemStatus { }

    [DataContract]
    public class SystemStatusTool : v2.SystemStatusTool { }
}
