﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace WooCommerceNET.WooCommerce.v3
{
    [DataContract]
    public class PaymentGateway : v2.PaymentGateway { }
}
