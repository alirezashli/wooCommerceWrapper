﻿using System.Runtime.Serialization;

namespace WooCommerceNET.WooCommerce.v3
{
    [DataContract]
    public class TaxRate : v2.TaxRate { }
}
