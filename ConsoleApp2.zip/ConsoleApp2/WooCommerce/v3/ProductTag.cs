﻿using System.Runtime.Serialization;

namespace WooCommerceNET.WooCommerce.v3
{
    [DataContract]
    public class ProductTag : v2.ProductTag { }
}
